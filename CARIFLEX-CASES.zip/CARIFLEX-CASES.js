# CASES FEITA POR MIM CRICIAN JS, FIZ PARA NAO DAR MUITO TRABALHO PRA VOCÊS. 

#CASO QUEIRA COMPRA UMA APIKEY PERSONALIZADA  ENTRE EM CONTATO COMIGO +559681361714

#LINKS  ⇩

#CANAL: https://whatsapp.com/channel/0029VavqcVdDDmFMz3Xkjy15

#API: https://cariflex.xyz


#DOWNLOADS YOUTUBE ✰

case 'play':
if(!q) return reply(`Exemplo: ${prefix}play nome da música`)
api = await fetchJson(`https://cariflex.xyz/api/play_audio?query=${q}&apikey=${API_CARIFLEX}`)
bla = `        ≪    ᴄᴀʀɪғʟᴇx ᴘʟᴀʏs    ≫
❤⃤ ᴛɪᴛᴜᴛᴏ: ${api.resultado.titulo}
❤⃤ ᴠɪᴇᴡs: ${api.resultado.views}
❤⃤ ᴛᴇᴍᴘᴏ: ${api.resultado.tempo}
❤⃤ ᴅᴇsᴄʀɪᴄ̧ᴀ̃ᴏ: ${api.resultado.canal}`
await cariflex.sendMessage(from,{image:{url:`${api.resultado.imagem}`},caption:bla},{quoted: info})
await cariflex.sendMessage(from, {audio: {url:`${api.resultado.audio}`},mimetype: "audio/mpeg"}, {quoted: info}).catch(e => {
reply("Nao foi possível encontrar o audio da música.")
})
break

case 'play2':
if(!q) return reply(`nome da musica`)
await sleep(300) 
api = await fetchJson(`https://cariflex.xyz/youtube/pesquisar?q=${q}&apikey=${API_CARIFLEX}`)
await cariflex.sendMessage(from,{audio:{url: `https://cariflex.xyz/api/youtube/mp3?url=${api.resultado[0].url}&apikey=${API_CARIFLEX}` }, mimetype: "audio/mpeg",
headerType: 4,contextInfo: {externalAdReply: {title: `${pushname}`,
body: `${api.resultado[0].title}`,showAdAttribution: true,
thumbnail: await getBuffer(`${api.resultado[0].image}`),
mediaType: 2,mediaUrl: `https://cariflex.xyz`,sourceUrl: `https://cariflex.xyz`}}},{quoted: live}).catch(e => {
reply("Nao foi possível encontrar o audio da música.")
}) 
break

case 'play3':
try {
if(!q) return reply(`exemplo ${prefix+command} mtg  na imaginação`)
api = await fetchJson(`https://cariflex.xyz/youtube/pesquisar?q=${q}&apikey=${API_CARIFLEX}`)
await cariflex.sendMessage(from,{audio:{url:`https://cariflex.xyz/api/youtube/mp3?url=${api.resultado[0].url}&apikey=${API_CARIFLEX}`},fileName: api.resultado[0].title+'.m4a', mimetype: "audio/mpeg", contextInfo: {externalAdReply: {title: api.resultado[0].title,
body: `0:00 ━❍────────-${api.resultado[0].duration || "indefinido"} ↻ ⊲ Ⅱ ⊳ ↺`,mediaType: 1,reviewType: "PHOTO", 
thumbnailUrl: api.resultado[0].image,showAdAttribution: true,
renderLargerThumbnail: true,}}}, {quoted: info}).catch(e => {
reply("Nao foi possível encontrar o audio da música.")
})
} catch (e) {
console.log(e)
}
break

case 'play4':
if(!q) return reply(`informe o nome da música`)
try {
api = await fetchJson(`https://cariflex.xyz/youtube/pesquisar?q=${q}&apikey=${API_CARIFLEX}`)
ytbrt = `ৡৢ͜͡𝔬⃝Titulo: ${api.resultado[0].title}
ৡৢ͜͡𝔬⃝Canal: ${api.resultado[0].autor || "indefinido"}
ৡৢ͜͡𝔬⃝Duração: ${api.resultado[0].seconds}
ৡৢ͜͡𝔬⃝Descrição: ${api.resultado[0].description}`
await cariflex.sendMessage(from, {image: {url: `${api.resultado[0].image}`}, caption: ytbrt}, {quoted: info})
await cariflex.sendMessage(from,{audio:{url:`https://cariflex.xyz/api/youtube/mp3-2?url=${api.resultado[0].url}&apikey=${API_CARIFLEX}` }, mimetype: "audio/mpeg"},{ quoted: info})
} catch (erro) {
reply("Nao foi possível encontrar o audio da música.")
console.log(erro)
}
break

case 'play5':
if(!q) return reply(`informe o nome da música`)
try {
await cariflex.sendMessage(from,{audio: {url:`https://cariflex.xyz/api/youtube/play?query=${q}&apikey=${API_CARIFLEX}`},mimetype: "audio/mpeg"},{quoted: info});
} catch (erro) {
reply("Nao foi possível encontrar o audio da música.")
console.log(erro)
}
break

case 'ytmp3': 
if(!q) return reply(`Cade o link do áudio?`)
await cariflex.sendMessage(from, {audio: {url: `https://cariflex.xyz/api/youtube/mp3?url=${q}&apikey=${API_CARIFLEX}`}, mimetype: "audio/mpeg"},{quoted: info}).catch(err => {
reply("ocorreu um erro")
})
break

case 'ytmp4':
if(!q) return reply(`Cade o link do video ?`)
await cariflex.sendMessage(from, {video: {url: `https://cariflex.xyz/api/youtube/mp4-2?url=${q}&apikey=${API_CARIFLEX}`}, mimetype: "video/mp4"}, {quoted: info}).catch(e => {
reply("ocorreu um erro")
})
break

#DOWNLOADS  FACEBOOK ✩

case 'facemp4':
if(!q) return reply("adicione o link de Facebook para baixar")
await cariflex.sendMessage(from, {video: {url:`https://cariflex.xyz/api/facebook/mp4?url=${q}&apikey=${API_CARIFLEX}`}, mimetype: "video/mp4"}, {quoted: info}).catch(e => {
console.log(e)
reply("ocoreu um erro")
})
break

case 'facemp3':
if(!q) return reply("adicione o link de Facebook para baixar")
await cariflex.sendMessage(from, {audio: {url:`https://cariflex.xyz/api/facebook/mp4?url=${q}&apikey=${API_CARIFLEX}`}, mimetype: "audio/mpeg"}, {quoted: info}).catch(e => {
console.log(e)
reply("ocorreu um erro")
})
break

#DOWNLOADS INSTAGRAM ✰

case 'instamp4':
if(!q) return reply(`Coloque o link do Instagram`);
await cariflex.sendMessage(from, {video: {url:`https://cariflex.xyz/api/instagram?url=${q}&apikey=${API_CARIFLEX}`}, mimetype: "video/mp4"}, {quoted: info}).catch(e => {
console.log(e)
reply("ocorreu um erro")
})
break

case 'instamp3':
if(!q) return reply("adicione o link de Instagram para baixar")
await cariflex.sendMessage(from, {audio: {url:`https://cariflex.xyz/api/instagram?url=${q}&apikey=${API_CARIFLEX}`}, mimetype: "audio/mpeg"}, {quoted: info}).catch(e => {
console.log(e)
reply("ocorreu um erro")
})
break

#DOWNLOADS TIKTOK ✰

case 'tiktok_video':
case 'tiktokvideo':
if(!q.includes("tiktok")) return reply(`${prefix+command} link do Tiktok`);
api = await fetchJson(`https://cariflex.xyz/api/tiktok-3?url=${q}&apikey=${API_CARIFLEX}`)
await cariflex.sendMessage(from, {video: {url:`${api.resultado.url}`}, mimetype: "video/mp4"}, {quoted: info}).catch(e => {
console.log(e)
reply("ocorreu um erro")
})
break

case 'tiktok_audio':
case 'tiktokaudio':
if(!q.includes("tiktok")) return reply(`${prefix+command} link do Tiktok`);
api = await fetchJson(`https://cariflex.xyz/api/tiktok-3?url=${q}&apikey=${API_CARIFLEX}`)
cariflex.sendMessage(from, {audio: {url:`${api.resultado.url}`}, mimetype: "audio/mpeg"}, {quoted: info}).catch(e => {
console.log(e)
reply("ocorreu um erro")
})
break

case 'tiktokmp4':
case 'Tiktokmp4':
if(!q.includes("tiktok")) return reply(`${prefix+command} link do Tiktok`);
await cariflex.sendMessage(from, {video: {url:`https://cariflex.xyz/api/tiktok/dl?url=${q}&apikey=${API_CARIFLEX}`}, mimetype: "video/mp4"}, {quoted: info}).catch(e => {
console.log(e)
reply("ocorreu um erro")
})
break

case 'tiktokmp3':
case 'Tiktokmp3':
if(!q.includes("tiktok")) return reply(`${prefix+command} link do Tiktok`)
await cariflex.sendMessage(from, {audio: {url:`https://cariflex.xyz/api/tiktok/dl?url=${q}&apikey=${API_CARIFLEX}`}, mimetype: "audio/mpeg"}, {quoted: info}).catch(e => {
console.log(e)
reply("ocorreu um erro")
})
break

#DOWNLOADS XVIDEOS ✰

case 'xvideos':
case 'xvideo':
if(!q) return reply('Por favor, informe o link do video.')
data = await fetchJson(`https://cariflex.xyz/api/download/xvideos?query=${q}&apikey=${API_CARIFLEX}`) 
await cariflex.sendMessage(sender, {video: {url: `${data.videoUrl}`} ,mimetype: 'video/mp4'}, {quoted: info}).catch(e => {
reply("ocorreu um erro")
})
break

#DOWNLOADS PINTEREST ✰

case 'pinterest': 
if(!q) return reply(`Digite o nome da imagem que vc quer buscar`)
blap = await getBuffer(`https://cariflex.xyz/api/pinterest?text=${q}&apikey=${API_CARIFLEX}`)
await cariflex.sendMessage(from, {image: blap, thumbnail: null}, {quoted: info}).catch(e => {
reply("ocorreu um erro")
})
break

case 'pintemp4':
if(!q) return reply("adicione o link de pinterest para baixar")
await cariflex.sendMessage(from, {video: {url:`https://cariflex.xyz/api/pinterest/mp4?url=${q}&apikey=${API_CARIFLEX}`}, mimetype: "video/mp4"}, {quoted: info}).catch(e => {
console.log(e)
reply("ocorreu um erro")
})
break

case 'pintemp3':
if(!q) return reply("adicione o link de pinterest para baixar")
await cariflex.sendMessage(from, {audio: {url:`https://cariflex.xyz/api/pinterest/mp3?url=${q}&apikey=${API_CARIFLEX}`}, mimetype: "audio/mpeg"}, {quoted: info}).catch(e => {
console.log(e)
reply("ocorreu um erro")
})
break

#ANIMES RANDOM 

case 'toukachan': 
case 'megumin':
case 'keneki':
case 'onepiece':
case 'tsunade':
case 'sasuke':
case 'sakura':
case 'madara':
case 'itachi':
case 'inori':
case 'hestia':
case 'chitoge':
case 'emilia':
case 'avusawa':
case 'asuna':
case 'deidara':
case 'anna':
case 'rize':
case 'nezuko':
case 'sagari':
case 'minato':
case 'naruto':
case 'hinata':
case 'elaina':
case 'erza':
case 'eba':
case 'shinka':
case 'kagura':
case 'shina':
case 'isuku':
case 'gremory':
case 'akiyama':
case 'mikasa':
case 'kotori':
case 'kaga':
case 'shizuka':
case 'kaori':
case 'boruto':
case 'chiho':
case 'tejina':
case 'yumeko':
case 'shinomiya':
case 'yotsuba':
case 'shota':
case 'loli':
case 'waifu':
api = await getBuffer(`https://cariflex.xyz/random/${command}?apikey=${API_CARIFLEX}`)
await cariflex.sendMessage(from, {image: api, thumbnail: null}, {quoted: info}).catch(e => {
reply("ocorreu um erro")
})
break

case 'edit-sakura':
case 'edit-aleatorios':
case 'edit-bleach':
case 'edit-chain':
case 'edit-slayer':
case 'edit-dragon':
case 'edit-hunters':
case 'edit-kaisen':
case 'edit-naruto':
await cariflex.sendMessage(from, { video: { url:`https://cariflex.xyz/api/editsvideo?categoria=${command}&apikey=${API_CARIFLEX}`} }, { quoted: info }).catch(e => {
reply("ocorreu um erro")
})
break;

#ANIMES HENTAIS 

case 'hentai-gay':
case 'lesbian':
case 'ass':
case 'bdms':
case 'blowjob': 
case 'cuckold':
case 'cum':
case 'ero':
case 'femdom':
case 'foot': 
case 'gankbang':
case 'glasses':
case 'hentai':
case 'jahy':
case 'manga':
case 'neko':
case 'orgy':
case 'panties':
case 'pussy':
case 'neko2':
case 'tentacles':
case 'thighs':
case 'yuri':
case 'zettai':
api = await getBuffer(`https://cariflex.xyz/nsfw/${command}?apikey=${API_CARIFLEX}`)
await cariflex.sendMessage(sender, {image:api, thumbnail: null}, {quoted: info}).catch(e => {
reply("ocorreu um erro")
})
break

case 'hentai-vid'://by tzn
try {
const gozeiprahentai = await fetchJson(`https://cariflex.xyz/api/random/hentai?apikey=${API_CARIFLEX}`);
if (gozeiprahentai.resultado && gozeiprahentai.resultado.length > 0) {
const gozeinocllr = gozeiprahentai.resultado[0];
await cariflex.sendMessage(sender, {video: {url: gozeinocllr.video_2}, caption: `
Título: ${gozeinocllr.title}
Categoria: ${gozeinocllr.category}
Visualizações: ${gozeinocllr.views_count}
Compartilhamentos: ${gozeinocllr.share_count}`, 
mimetype: "video/mp4"}, {quoted: info});
} else {//by tzn
reply('encontrei video n');
}
} catch {
reply("ocorreu um erro")
}
break

#OUTRAS FUNÇÕES 

case 'gerarqr': 
if(!q) return reply(`Digite o nome para gerar o qr`)
reply( "Gerando seu qrcode")
await sleep(3000)
cari = await getBuffer(`https://cariflex.xyz/api/outros/qrcode?texto=${q}&apikey=${API_CARIFLEX}`)
await cariflex.sendMessage(from, {image: cari}, {quoted: info}).catch(e => {
console.log(e) 
reply("ocorreu um erro")
})
break

case 'key':
case 'Key':
try {
await sleep(2000)
cari = await fetchJson(`https://cariflex.xyz/api/keyerrada?apikey=Sua key`)
await cariflex.sendMessage(from, {text: `${cari.request}`}, {quoted: info})
} catch (error) {
reply("ocorreu um erro")
}
break

case 'nome':
case 'telefone':
case 'cpf':
case 'cpf2':
case 'placa':
case 'cnpj':
if (!q) return reply('Informe o dado que deseja consultar após o comando.');
reply('Consultando...');
const consulta = await fetchJson(`https://cariflex.xyz/api/consulta/${command}?query=${q}&apikey=${API_CARIFLEX}`);
if (consulta.file) {
const resultado = Buffer.from(consulta.base64, 'base64'); 
await cariflex.sendMessage(from, { document: resultado, fileName: `${q}.txt`, mimetype: 'text/plain' });
}
else {
if (consulta.resultado) {
await cariflex.sendMessage(from, { text: consulta.resultado });
}
}
break

case 'gethtml':
if(!q) return reply("cade o url do site")
try {
reply("Aguarde um momento enquanto extraio o html")
await sleep(3000)
cari = await fetchJson(`https://cariflex.xyz/api/outros/get-html?url=${q}&apikey=${API_CARIFLEX}`)
await cariflex.sendMessage(from, {text: `${cari.resultado}`}, {quoted: info})
} catch (error) {
reply(" ocorreu um erro ao extrair o html") 
}
break

case 'gerar-image': 
case 'image-ai':
if(!q) return reply(`Digite o nome para gerar a imagem`)
reply('estou gerando sua imagem')
api = await fetchJson(`https://cariflex.xyz/api/ai/gerar/image?query=${q}&apikey=${API_CARIFLEX}`)
await cariflex.sendMessage(from, {image: {url: `${api.image}`}}, {quoted: info}).catch(e => {
reply('nao foi possível gerar a imagem')
})
break

case 'figurinhas':
if (!Number(q)) return reply(`Digite a quantidade de figurinhas\nExemplo: ${prefix+command} 100`)
if (q >= 100) return reply("Coloque abaixo de 100..")
if (isGroup) reply(`As figurinhas estão sendo enviadas em seu pv.`)
async function figu_ale() {
var rnd = Math.floor(Math.random() * 8051)
await cariflex.sendMessage(sender, {
sticker: {
url: `https://cariflex.xyz/sticker/figurinhas_ale?apikey=${API_CARIFLEX}`
}
})}
for (i = 0; i < q; i++) {
await sleep(1000)
figu_ale()
}
break

case 'pensador': case 'Pensador':
if (!q) return reply(`informe o nome da pesquisa`)
try {
api = await fetchJson(`https://cariflex.xyz/search/pensador?query=${q}&apikey=${API_CARIFLEX}`)
await cariflex.sendMessage(from, {image: {url: `https://i.imgur.com/MvFF0jm.jpeg`}, caption: `${api.resultado[0].frase}`}, {quoted: info})
} catch (error) {
console.log(e)
}
break

case 'decodificar':
if (!q) return reply(`Coloque o código codificado para transformar em texto`)
try {// ᴄʀɪᴄɪᴀɴ ᴊs
code = await fetchJson(`https://cariflex.xyz/api/outros/decodificar?query=${q}&apikey=${API_CARIFLEX}`)
await cariflex.sendMessage(from, {text: `${code.decodificado}`}, {quoted: info})
} catch (error) {
console.log(e)
}
break

case 'codificar':
if (!q) return reply(`Coloque o texto para transformar em código`)
try {// ᴄʀɪᴄɪᴀɴ ᴊs
code = await fetchJson(`https://cariflex.xyz/api/outros/codificar?query=${q}&apikey=${API_CARIFLEX}`)
await cariflex.sendMessage(from, {text: `${code.codificado}`}, {quoted: info})
} catch (error) {
console.log(e)
}
break

case 'metadinha':
reagir(from, "💖")
met = await fetchJson(`https://cariflex.xyz/random/metadinha?apikey=${API_CARIFLEX}`)
await cariflex.sendMessage(sender,{image:{url:met.masculina}},{quoted: info})
await cariflex.sendMessage(sender,{image:{url:met.feminina}},{quoted: info})
break

case 'plaq1': 
case 'plaq2':
case 'plaq3':
case 'plaq4':
case 'plaq5':
case 'plaq6':
case 'plaq7':
case 'plaq8':
case 'plaq9':
case 'plaq10':
if(!q) return reply(`informe o seu nome`)
cari = await getBuffer(`https://cariflex.xyz/api/${command}?q=${q}&apikey=${API_CARIFLEX}`)
await cariflex.sendMessage(sender, {image: cari, thumbnail: null}, {quoted: info}).catch(e => {
reply('Erro ao fazer sua plaquinha')
})
break

case 'lgbt': 
case 'hitler':
case 'pixelate': 
case 'sepia': 
case 'trash':
case 'wanted': 
case 'wasted': 
case 'rip': 
case 'jail':
case 'facepalm':
case 'invert': 
case 'del': 
case 'circle': 
case 'beautiful':
case 'blur':
case 'bolsonaro': 
case 'bobross': 
case 'mms': 
case 'comunismo':
if ((isMedia && !info.message.videoMessage || isQuotedImage)) {
post = isQuotedImage ? JSON.parse(JSON.stringify(info).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo.message.imageMessage : info.message.imageMessage;
imagem = await downloadContentFromMessage(post, 'image');
base64 = Buffer.from([]);
for await (const send of imagem) {
base64 = Buffer.concat([base64, send]);
}
const clientID = '400116076ba4b73'; 
const imgurUrl = 'https://api.imgur.com/3/upload';    
const response = await fetch(imgurUrl, {
method: 'POST',
headers: {
Authorization: `Client-ID ${clientID}`,
Accept: 'application/json',
},
body: new URLSearchParams({
image: base64.toString('base64'),
type: 'base64'
})
});
const result = await response.json();
const link = result.data.link;
cariflex.sendMessage(from, {image: {url:`https://cariflex.xyz/api/canvas/${command}?link=${link}&apikey=${API_CARIFLEX}`}}, {quoted: info})
} else {
reply("Mencione uma imagem para atribuir o efeito à foto.");
}
break

case 'cosplay': 
case 'Cosplay':
api = await getBuffer(`https://cariflex.xyz/random/cosplay?apikey=${API_CARIFLEX}`)
await cariflex.sendMessage(from, {image: api, thumbnail: null}, {quoted: info}).catch(e => {
reply('Erro ao fornecer o resultado da sua pesquisa. Tente novamente mais tarde!')
})
break

case 'serie': case 'Serie':
if (!q) return reply(`informe o nome da serie`)
try {
api = await fetchJson(`https://cariflex.xyz/api/serie?title=${q}&apikey=${API_CARIFLEX}`)
await cariflex.sendMessage(from, {image: {url: `${api.resultado.poster}`}, caption:`TITULO: ${api.resultado.name}\nNOME-ORIGINAL: ${api.resultado.originalName}\nIDIOMA: ${api.resultado.language}\nADULTO: ${api.resultado.adult}\nDESCRIÇÃO: ${api.resultado.overview}`}, {quoted: info})
} catch (error) {
console.log(e)
}
break

case 'nerding': case 'Nerding':
if (!q) return reply(`informe a seu título`)
try {
nerd = await fetchJson(`https://cariflex.xyz/api/nerding?q=${q}&apikey=${API_CARIFLEX}`)
await cariflex.sendMessage(from, {image: {url: `https://i.imgur.com/grB8Khl.jpeg`}, caption: `*TITULO*: ${nerd.resultado[0].titulo}\n*DESC*: ${nerd.resultado[0].desc}\n*URL*: ${nerd.resultado[0].link}`}, {quoted: info})
} catch (error) {
console.log(e)
}
break

case 'letra': case'Letra':
if (!q) return reply(`informe o nome da música`)
try {
api = await fetchJson(`https://cariflex.xyz/api/pesquisa/letramusica?query=${q}&apikey=${API_CARIFLEX}`)
await cariflex.sendMessage(from, {image: {url: `${api.resultado.image}`}, caption: `${api.resultado.titulo}\n${api.resultado.artista}\n${api.resultado.letra}`}, {quoted: info})
} catch (error) {
console.log(e)
}
break   